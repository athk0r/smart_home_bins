#!/usr/bin/env python3
import sys
import subprocess
import os
import PyQt5
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
import mainwindow_auto

class MainWindow(QMainWindow, mainwindow_auto.Ui_MainWindow):
    # Zustand des Sensors zur Demonstration der Signalstörung
    def changeStateSigStoerung(self):
        if self.switchStateSignalstoerung.isChecked():
            print("Fenster Sig. Störung auf")
            #subprocess.call("ZustandEin.sh"
            os.system('pgrep disturb | xargs kill -10');
        else:
            print("Fenster Sig. Störung zu")
            #subprocess.call("ZustandAus.sh")
            os.system('pgrep disturb | xargs kill -10');

    # Signalstörung ein/aus Schalten
    def Stoerung(self):
        if self.StoerungEinAus.isChecked():
            print("Störung Ein")
            os.system('echo "raspberry" | sudo -s ip6tables -A OUTPUT -j DROP -s fd29:144d:4196:94::53')
        else:
            print("Störung Aus")
            os.system('echo "raspberry" | sudo -s  ip6tables -D OUTPUT -j DROP -s fd29:144d:4196:94::53')

    # Zustand des Sensors zur Demonstration der Paketverdopplung
    def changeStatePaketverdopplung(self):
        if self.switchStatePaketverdoppelung.isChecked():
            print("Fenster Verdopplung auf")
            os.system('pgrep duplicate | xargs kill -12');

        else:
            print("Fenster Verdopplung zu")
            os.system('pgrep duplicate | xargs kill -12');

    # Zustand des Sensors zur Demonstration des Herdes
    def changeStateHerd(self):
        if self.HerdOnOff.isChecked():
            print("Herd Ein")
            os.system('pgrep herd | xargs kill -10');
        else:
            print("Herd Aus")
            os.system('pgrep herd | xargs kill -10');

    # Zustand des Sensors zur Demonstration des Wassers
    def changeStateWasser(self):
        if self.WasserOnOff.isChecked():
            print("Wasser Ein") 
            os.system('pgrep wasser | xargs kill -10');
        else:
            print("Wasser Aus")
            os.system('pgrep wasser | xargs kill -10');
    # Paketverdopplung starten
    def Verdopplung(self):
        print("Paketverdopplung eigeschaltet")






    def __init__(self):
        super(self.__class__, self).__init__()
        self.setupUi(self)
        self.switchStateSignalstoerung.clicked.connect(lambda: self.changeStateSigStoerung())
        self.StoerungEinAus.clicked.connect(lambda: self.Stoerung())
        self.switchStatePaketverdoppelung.clicked.connect(lambda: self.changeStatePaketverdopplung())
        self.HerdOnOff.clicked.connect(lambda: self.changeStateHerd())
        self.WasserOnOff.clicked.connect(lambda: self.changeStateWasser())
        self.VerdopplungEinAus.clicked.connect(lambda: self.Verdopplung())


def main():

    app = QApplication(sys.argv)
    form = MainWindow()
    form.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
