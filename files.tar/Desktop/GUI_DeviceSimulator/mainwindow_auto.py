# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'mainwindow.ui'
#
# Created by: PyQt5 UI code generator 5.8.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 480)
        MainWindow.setAutoFillBackground(False)
        MainWindow.showFullScreen()
        self.centralWidget = QtWidgets.QWidget(MainWindow)
        self.centralWidget.setObjectName("centralWidget")
        self.groupHerd = QtWidgets.QGroupBox(self.centralWidget)
        self.groupHerd.setGeometry(QtCore.QRect(400, 0, 200, 480))
        self.groupHerd.setAutoFillBackground(False)
        self.groupHerd.setStyleSheet("QGroupBox {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #E0E0E0, stop: 1 #FFFFFF);\n"
"    border: 2px solid gray;\n"
"    border-radius: 5px;\n"
"    margin-top: 1ex; /* leave space at the top for the title */\n"
"\n"
"font-size: 18px;\n"
"    font-weight: bold;\n"
"\n"
"}\n"
"QGroupBox::title {\n"
"    subcontrol-origin: margin;\n"
"    subcontrol-position: top center; /* position at the top center */\n"
"    padding: 0 3px;\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 , stop: 1 #FFFFFF);\n"
"}")
        self.groupHerd.setObjectName("groupHerd")
        self.HerdOnOff = QtWidgets.QPushButton(self.groupHerd)
        self.HerdOnOff.setGeometry(QtCore.QRect(0, 20, 200, 460))
        self.HerdOnOff.setStyleSheet("font: bold 14px;")
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("Icons/fire-off.png"), QtGui.QIcon.Active, QtGui.QIcon.Off)
        icon.addPixmap(QtGui.QPixmap("Icons/fire-on.png"), QtGui.QIcon.Active, QtGui.QIcon.On)
        self.HerdOnOff.setIcon(icon)
        self.HerdOnOff.setIconSize(QtCore.QSize(50, 50))
        self.HerdOnOff.setCheckable(True)
        self.HerdOnOff.setObjectName("HerdOnOff")
        self.groupBoxWasser = QtWidgets.QGroupBox(self.centralWidget)
        self.groupBoxWasser.setGeometry(QtCore.QRect(600, 0, 200, 480))
        self.groupBoxWasser.setStyleSheet("QGroupBox {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #E0E0E0, stop: 1 #FFFFFF);\n"
"    border: 2px solid gray;\n"
"    border-radius: 5px;\n"
"    margin-top: 1ex; /* leave space at the top for the title */\n"
"\n"
"font-size: 18px;\n"
"    font-weight: bold;\n"
"}\n"
"QGroupBox::title {\n"
"    subcontrol-origin: margin;\n"
"    subcontrol-position: top center; /* position at the top center */\n"
"    padding: 0 3px;\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 stop: 1 #FFFFFF);\n"
"}")
        self.groupBoxWasser.setObjectName("groupBoxWasser")
        self.WasserOnOff = QtWidgets.QPushButton(self.groupBoxWasser)
        self.WasserOnOff.setGeometry(QtCore.QRect(0, 20, 200, 460))
        self.WasserOnOff.setStyleSheet("font: bold 14px;")
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap("Icons/faucet-off.png"), QtGui.QIcon.Active, QtGui.QIcon.Off)
        icon1.addPixmap(QtGui.QPixmap("Icons/faucet-on.png"), QtGui.QIcon.Active, QtGui.QIcon.On)
        self.WasserOnOff.setIcon(icon1)
        self.WasserOnOff.setIconSize(QtCore.QSize(50, 50))
        self.WasserOnOff.setCheckable(True)
        self.WasserOnOff.setObjectName("WasserOnOff")
        self.groupVerdopplung = QtWidgets.QGroupBox(self.centralWidget)
        self.groupVerdopplung.setGeometry(QtCore.QRect(200, 0, 200, 480))
        self.groupVerdopplung.setStyleSheet("QGroupBox {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #E0E0E0, stop: 1 #FFFFFF);\n"
"    border: 2px solid gray;\n"
"    border-radius: 5px;\n"
"    margin-top: 1ex; /* leave space at the top for the title */\n"
"font-size: 18px;\n"
"    font-weight: bold;\n"
"}\n"
"QGroupBox::title {\n"
"    subcontrol-origin: margin;\n"
"    subcontrol-position: top center; /* position at the top center */\n"
"    padding: 0 3px;\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 , stop: 1 #FFFFFF);\n"
"}")
        self.groupVerdopplung.setObjectName("groupVerdopplung")
        self.switchStatePaketverdoppelung = QtWidgets.QPushButton(self.groupVerdopplung)
        self.switchStatePaketverdoppelung.setGeometry(QtCore.QRect(0, 20, 200, 220))
        self.switchStatePaketverdoppelung.setStyleSheet("font: bold 14px;")
        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap("Icons/window-closed.png"), QtGui.QIcon.Active, QtGui.QIcon.Off)
        icon2.addPixmap(QtGui.QPixmap("Icons/window-open.png"), QtGui.QIcon.Active, QtGui.QIcon.On)
        self.switchStatePaketverdoppelung.setIcon(icon2)
        self.switchStatePaketverdoppelung.setIconSize(QtCore.QSize(50, 50))
        self.switchStatePaketverdoppelung.setCheckable(True)
        self.switchStatePaketverdoppelung.setObjectName("switchStatePaketverdoppelung")
        self.VerdopplungEinAus = QtWidgets.QPushButton(self.groupVerdopplung)
        self.VerdopplungEinAus.setEnabled(False)
        self.VerdopplungEinAus.setGeometry(QtCore.QRect(0, 250, 200, 225))
        self.VerdopplungEinAus.setStyleSheet("font: bold 14px;")
        icon3 = QtGui.QIcon()
        icon3.addPixmap(QtGui.QPixmap("Icons/PaketverdopplungAus.png"), QtGui.QIcon.Active, QtGui.QIcon.Off)
        icon3.addPixmap(QtGui.QPixmap("Icons/PaketverdopplungEin.png"), QtGui.QIcon.Active, QtGui.QIcon.On)
        self.VerdopplungEinAus.setIcon(icon3)
        self.VerdopplungEinAus.setIconSize(QtCore.QSize(50, 50))
        self.VerdopplungEinAus.setCheckable(False)
        self.VerdopplungEinAus.setAutoRepeat(False)
        self.VerdopplungEinAus.setObjectName("VerdopplungEinAus")
        self.groupStoerung = QtWidgets.QGroupBox(self.centralWidget)
        self.groupStoerung.setGeometry(QtCore.QRect(0, 0, 200, 480))
        self.groupStoerung.setAutoFillBackground(False)
        self.groupStoerung.setStyleSheet("QGroupBox {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #E0E0E0, stop: 1 #FFFFFF);\n"
"    border: 2px solid gray;\n"
"    border-radius: 5px;\n"
"    margin-top: 1ex; /* leave space at the top for the title */\n"
"font-size: 18px;\n"
"    font-weight: bold;\n"
"}\n"
"QGroupBox::title {\n"
"    subcontrol-origin: margin;\n"
"    subcontrol-position: top center; /* position at the top center */\n"
"    padding: 0 3px;\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 , stop: 1 #FFFFFF);\n"
"}")
        self.groupStoerung.setObjectName("groupStoerung")
        self.switchStateSignalstoerung = QtWidgets.QPushButton(self.groupStoerung)
        self.switchStateSignalstoerung.setGeometry(QtCore.QRect(0, 20, 200, 220))
        self.switchStateSignalstoerung.setStyleSheet("font: bold 14px;")
        icon4 = QtGui.QIcon()
        icon4.addPixmap(QtGui.QPixmap("Icons/door-closed.png"), QtGui.QIcon.Active, QtGui.QIcon.Off)
        icon4.addPixmap(QtGui.QPixmap("Icons/door-open.png"), QtGui.QIcon.Active, QtGui.QIcon.On)
        self.switchStateSignalstoerung.setIcon(icon4)
        self.switchStateSignalstoerung.setIconSize(QtCore.QSize(50, 50))
        self.switchStateSignalstoerung.setCheckable(True)
        self.switchStateSignalstoerung.setObjectName("switchStateSignalstoerung")
        self.StoerungEinAus = QtWidgets.QPushButton(self.groupStoerung)
        self.StoerungEinAus.setGeometry(QtCore.QRect(0, 250, 200, 225))
        self.StoerungEinAus.setStyleSheet("font: bold 14px;")
        icon5 = QtGui.QIcon()
        icon5.addPixmap(QtGui.QPixmap("Icons/SignalstoerungAus.png"), QtGui.QIcon.Active, QtGui.QIcon.Off)
        icon5.addPixmap(QtGui.QPixmap("Icons/Signalstoerung.png"), QtGui.QIcon.Active, QtGui.QIcon.On)
        self.StoerungEinAus.setIcon(icon5)
        self.StoerungEinAus.setIconSize(QtCore.QSize(50, 50))
        self.StoerungEinAus.setCheckable(True)
        self.StoerungEinAus.setAutoRepeat(False)
        self.StoerungEinAus.setObjectName("StoerungEinAus")
        MainWindow.setCentralWidget(self.centralWidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.groupHerd.setTitle(_translate("MainWindow", "Herd"))
        self.HerdOnOff.setText(_translate("MainWindow", "An/Aus"))
        self.groupBoxWasser.setTitle(_translate("MainWindow", "Wasser"))
        self.WasserOnOff.setText(_translate("MainWindow", "An/Aus"))
        self.groupVerdopplung.setTitle(_translate("MainWindow", "Paketverdopplung"))
        self.switchStatePaketverdoppelung.setText(_translate("MainWindow", "Auf / Zu"))
        self.VerdopplungEinAus.setText(_translate("MainWindow", "Paketver\n"
"dopplung\n"
" Starten"))
        self.groupStoerung.setTitle(_translate("MainWindow", "Signalstörung"))
        self.switchStateSignalstoerung.setText(_translate("MainWindow", "Auf / Zu"))
        self.StoerungEinAus.setText(_translate("MainWindow", "Störung\n"
" Ein/Aus"))
