# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'mainwindow.ui'
#
# Created by: PyQt5 UI code generator 5.8.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 480)
        self.centralWidget = QtWidgets.QWidget(MainWindow)
        self.centralWidget.setObjectName("centralWidget")
        self.groupBox = QtWidgets.QGroupBox(self.centralWidget)
        self.groupBox.setGeometry(QtCore.QRect(400, 0, 200, 480))
        self.groupBox.setObjectName("groupBox")
        self.pushButton = QtWidgets.QPushButton(self.groupBox)
        self.pushButton.setGeometry(QtCore.QRect(10, 150, 100, 100))
        self.pushButton.setObjectName("pushButton")
        self.groupBox_2 = QtWidgets.QGroupBox(self.centralWidget)
        self.groupBox_2.setGeometry(QtCore.QRect(600, 0, 200, 480))
        self.groupBox_2.setObjectName("groupBox_2")
        self.pushButton_2 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_2.setGeometry(QtCore.QRect(10, 140, 100, 100))
        self.pushButton_2.setObjectName("pushButton_2")
        self.groupBox_3 = QtWidgets.QGroupBox(self.centralWidget)
        self.groupBox_3.setGeometry(QtCore.QRect(200, 0, 200, 480))
        self.groupBox_3.setObjectName("groupBox_3")
        self.groupBox_4 = QtWidgets.QGroupBox(self.centralWidget)
        self.groupBox_4.setGeometry(QtCore.QRect(0, 0, 200, 480))
        self.groupBox_4.setObjectName("groupBox_4")
        self.switchStateSignalstoerung = QtWidgets.QPushButton(self.groupBox_4)
        self.switchStateSignalstoerung.setGeometry(QtCore.QRect(10, 30, 100, 100))
        self.switchStateSignalstoerung.setCheckable(True)
        self.switchStateSignalstoerung.setObjectName("switchStateSignalstoerung")
        self.StoerungEinAus = QtWidgets.QPushButton(self.groupBox_4)
        self.StoerungEinAus.setGeometry(QtCore.QRect(10, 230, 100, 100))
        self.StoerungEinAus.setCheckable(True)
        self.StoerungEinAus.setAutoRepeat(False)
        self.StoerungEinAus.setObjectName("StoerungEinAus")
        MainWindow.setCentralWidget(self.centralWidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.groupBox.setTitle(_translate("MainWindow", "Herd"))
        self.pushButton.setText(_translate("MainWindow", "An/Aus"))
        self.groupBox_2.setTitle(_translate("MainWindow", "Wasser"))
        self.pushButton_2.setText(_translate("MainWindow", "An/Aus"))
        self.groupBox_3.setTitle(_translate("MainWindow", "Packetverdopplung"))
        self.groupBox_4.setTitle(_translate("MainWindow", "Signal Störung"))
        self.switchStateSignalstoerung.setText(_translate("MainWindow", "Auf / Zu"))
        self.StoerungEinAus.setText(_translate("MainWindow", "Störung\n"
" Ein/Aus"))

