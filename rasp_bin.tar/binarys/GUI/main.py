# From https://www.baldengineer.com/raspberry-pi-gui-tutorial.html
# by James Lewis (@baldengineer)
# Minimal python code to start PyQt5 GUI
#

# always seem to need this
import sys
import subprocess

# This gets the Qt stuff
import PyQt5
from PyQt5.QtWidgets import *

# This is our window from QtCreator
import mainwindow_auto

# create class for our Raspberry Pi GUI
class MainWindow(QMainWindow, mainwindow_auto.Ui_MainWindow):
    # access variables inside of the UI's file
    def changeStateSigStoerung(self):
        print("Zustand ändert sich")
        #subprocess.call("aendereZustand.sh")
    def Stoerung(self):
        if self.StoerungEinAus.isChecked():
            print("Störung Ein")
            #subprocess.call("stoerungEin.sh")
        else:
            print("Störung Aus")
            #subprocess.call("stoerungAus.sh")

    def __init__(self):
        super(self.__class__, self).__init__()
        self.setupUi(self) # gets defined in the UI file

        ### Hooks to for buttons
        self.switchStateSignalstoerung.clicked.connect(lambda: self.changeStateSigStoerung())
        self.StoerungEinAus.clicked.connect(lambda: self.Stoerung())

        #self.btnOn.clicked.connect(lambda: self.pressedOnButton())
        #self.btnOff.clicked.connect(lambda: self.pressedOffButton())

# I feel better having one of these
def main():
    # a new app instance
    app = QApplication(sys.argv)
    form = MainWindow()
    form.show()
    # without this, the script exits immediately.
    sys.exit(app.exec_())

# python bit to figure how who started This
if __name__ == "__main__":
    main()
