#!/bin/bash
./sdds4sh_devicesimulator_id_ip40_rep20_nonce_changeable << EOF
contactnonce 1 22
EOF
