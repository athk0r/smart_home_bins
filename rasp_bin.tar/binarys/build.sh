#!/bin/sh
make clean
./generate.sh
make
